<?php 

if( ! function_exists('bingo_stick_vc')){
    function bingo_stick_vc(){
        vc_map([
            'name'  => __('Stick Images','bingo'),
            'base'  => 'stick_slider',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'param_group',
                    'heading'   => __('Image','bingo'),
                    'param_name'    => 'stick_images',
                    'params'        => [
                        [
                            'type'  => 'attach_image',
                            'heading'   => __('Adding Image','bingo'),
                            'param_name'    => 'image',
                            'description'   => __('Upload an Image','bingo')
                        ]
                    ]
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_stick_vc');
}