<?php 

if( ! function_exists('our_services_vc')){
    function our_services_vc(){
        vc_map([
            'name'  => __('Our Services','bingo'),
            'base'  => 'bingo_services',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'param_group',
                    'heading'   => __('Adding Services','bingo'),
                    'param_name'    => 'services',
                    'params'        => [
                        [
                            'type'  => 'textfield',
                            'heading'   => __('Title Text','bingo'),
                            'param_name'    => 'title_text',
                            'description'   => __('Enter the Title','bingo')
                        ],
                        [
                            'type'  => 'textarea',
                            'heading'   => __('Content Text','bingo'),
                            'param_name'    => 'content_text',
                            'description'   => __('Enter Some Text to show as content', 'bingo')
                        ]

                    ]
                ]
            ]
        ]);
    }
    add_action('vc_before_init','our_services_vc');
}