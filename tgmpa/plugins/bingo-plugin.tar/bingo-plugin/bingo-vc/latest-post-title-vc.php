<?php 


if( ! function_exists('bingo_title_post_vc')){
    function bingo_title_post_vc(){
        vc_map([
            'name'  => __('Latest Post','bingo'),
            'base'  => 'latest_post',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'textfield',
                    'heading'   => __('Add Title','bingo'),
                    'param_name'    => 'title_text',
                    'description'   => __('Enter the Title','bingo'),
                    'admin_label'   => true
                ],
                
                [
                    'type'  => 'textarea',
                    'heading'   => __('Add content','bingo'),
                    'param_name'    => 'content_text',
                    'description'   => __('Enter soem text to show as content','bingo')
                ],

                [
                    'type'  => 'textfield',
                    'heading'   => __('Post Limit','bingo'),
                    'param_name'    => 'post_limit',
                    'description'   => __('Enter Post Limit','bingo')
                ],
            ]
        ]);
    }
    add_action('vc_before_init','bingo_title_post_vc');
}