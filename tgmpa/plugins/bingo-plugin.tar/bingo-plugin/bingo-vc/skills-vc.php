<?php 

if( ! function_exists('bingo_skills_vc')){
    function bingo_skills_vc(){
        vc_map([
            'name'  => __('Skills','bingo'),
            'base'  => 'skill',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'    => 'textfield',
                    'heading'  => __('Bingo Title','bingo'),
                    'param_name'    => 'title_text',
                    'description'   => esc_html('EX: Skill', 'bingo'),

                ],
                [
                    'type'    => 'textarea_html',
                    'heading'  => __('Bingo content','bingo'),
                    'param_name'    => 'content_text',
                    'description'   => esc_html('EX: Enter Some text to display', 'bingo'),
                     
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_skills_vc');
}