<?php 

if( ! function_exists('bingo_works_vc')){
    function bingo_works_vc(){
        vc_map([
            'name'  => __('Our Works','bingo'),
            'base'  => 'works',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'textfield',
                    'heading'   => __('Add Title','bingo'),
                    'param_name'    => 'title_text',
                    'description'   => __('EX: Our Works','bingo')
                ],
                [
                    'type'  => 'textarea_html',
                    'heading'   => __('Add Content','bingo'),
                    'param_name'    => 'content_text',
                    'description'   => __('Enter some text to show as content','bingo')
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_works_vc');
}