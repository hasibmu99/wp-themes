<?php 

if ( ! function_exists('bingo_testimonial_vc') ) {
    function bingo_testimonial_vc(){
        vc_map([
            'name'      => __('Testimonials','bingo'),
            'base'      => 'testimonial',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'          => 'param_group',
                    'heading'       => __('Add Testimonial ','bingo'),
                    'param_name'    => 'testimonials',
                    'params'        => [
                        [
                            'type'          => 'attach_image',
                            'heading'       => __('Client Image','bingo'),
                            'param_name'    => 'client_image',
                            'description'   => __('Upload an Image','bingo')
                        ],
                        [
                            'type'          => 'textarea',
                            'heading'       => __('Client Detail','bingo'),
                            'param_name'    => 'client_detail',
                            'description'   => __('Enter some text to show as detail','bingo')
                        ],
                        [
                            'type'          => 'textfield',
                            'heading'       => __('Client Name','bingo'),
                            'param_name'    => 'client_name',
                            'description'   => __('Ex: John','bingo')
                        ],
                        [
                            'type'          => 'textfield',
                            'heading'       => __('Client Designation','bingo'),
                            'param_name'    => 'client_designation',
                            'description'   => __('Ex: CFO, Google','bingo')
                        ]
                    ]
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_testimonial_vc');
}