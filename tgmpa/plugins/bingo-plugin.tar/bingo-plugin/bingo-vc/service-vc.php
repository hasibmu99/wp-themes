<?php 

if( ! function_exists('bingo_service_vc')){
    function bingo_service_vc(){
        vc_map([
            'name'  => __('Service','bingo'),
            'base'  => 'service',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'    => 'textfield',
                    'heading'  => __('Bingo Title','bingo'),
                    'param_name'    => 'title_text',
                    'description'   => esc_html('EX: Our Service', 'bingo'),

                ],
                [
                    'type'    => 'textarea_html',
                    'heading'  => __('Bingo content','bingo'),
                    'param_name'    => 'content_text',
                    'description'   => esc_html('EX: Enter Some text to display', 'bingo'),
                     
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_service_vc');
}