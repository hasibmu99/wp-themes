<?php 

if( ! function_exists('bingo_progress_vc')){
    function bingo_progress_vc(){
        vc_map([
            'name'  => __('Progress Sheet','bingo'),
            'base'  => 'progress',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'param_group',
                    'heading'   => __('Progress','bingo'),
                    'param_name'    => 'progresses',
                    'params'        => [
                        [
                            'type'  => 'textfield',
                            'heading'   => __('Progress Topic','bingo'),
                            'param_name'    => 'progress_topic',
                            'description'   => __('Ex: Enter the Progress Section','bingo')
                        ],
                        [
                            'type'  => 'textfield',
                            'heading'   => __('Progress percentage','bingo'),
                            'param_name'    => 'percentage',
                            'description'   => __('Ex: Enter the Progress Percentage','bingo')
                        ]
                    ]
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_progress_vc');
}