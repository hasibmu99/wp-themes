<?php 

if( ! function_exists('bingo_skill_left_vc')){
    function bingo_skill_left_vc(){
        vc_map([
            'name'  => __('Skill Left', 'bingo'),
            'base'  => 'skill_left',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'textfield',
                    'heading'   => __('Title Text','bingo'),
                    'param_name' => 'title_text',
                    'description'   => __('Enter the Title','bingo')
                ],
                [
                    'type'  => 'textarea_html',
                    'heading'   => __('Content Text','bingo'),
                    'param_name' => 'content_text',
                    'description'   => __('Enter the Content','bingo')
                ],
                [
                    'type'  => 'textfield',
                    'heading'   => __('Button Text','bingo'),
                    'param_name' => 'button_text',
                    'description'   => __('Enter the Button Text','bingo')
                ],
                [
                    'type'  => 'textfield',
                    'heading'   => __('Button link','bingo'),
                    'param_name' => 'button_link',
                    'description'   => __('Enter the Button Link','bingo')
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_skill_left_vc');
}