<?php

if( ! function_exists('bingo_awards_details')){
    function bingo_awards_details(){
        vc_map([
            'name'  => __('Awards Details','bingo'),
            'base'  => 'bingo_awards',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'param_group',
                    'heading'   => __('Adding Award','bingo'),
                    'param_name'    => 'awards',
                    'params'    => [
                        [
                            'type'  => 'textfield',
                            'heading'   => __('Adding Title','bingo'),
                            'param_name'    => 'title',
                            'description'   => __('Ex:Happy Client','bingo')
                        ],
                        [
                            'type'  => 'textfield',
                            'heading'   => __('Adding Maximum Number','bingo'),
                            'param_name'    => 'max_number',
                            'description'   => __('Ex: 150 ','bingo')
                        ],
                        [
                            'type'  => 'textfield',
                            'heading'   => __('Adding Minimum Number','bingo'),
                            'param_name'    => 'least_number',
                            'description'   => __('Ex: 0 ','bingo')
                        ],
                        [
                            'type'  => 'textfield',
                            'heading'   => __('Adding Icon','bingo'),
                            'param_name'    => 'icon',
                            'description'   => __('Enter An Nmae of Icon ','bingo')
                        ]
                    ]
                    
                ]
                
            ]
        ]);
    }
    add_action('vc_before_init','bingo_awards_details');
}