<?php 

if( ! function_exists('bingo_award_vc')){
    function bingo_award_vc(){
        vc_map([
            'name'  => __('Award','bingo'),
            'base'  => 'award',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'    => 'textfield',
                    'heading'  => __('Bingo Title','bingo'),
                    'param_name'    => 'title_text',
                    'description'   => esc_html('EX: Award Us', 'bingo'),

                ],
                [
                    'type'    => 'textarea_html',
                    'heading'  => __('Bingo content','bingo'),
                    'param_name'    => 'content_text',
                    'description'   => esc_html('EX: Enter Some text to display', 'bingo'),
                     
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_award_vc');
}