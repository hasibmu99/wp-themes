<?php 

if( ! function_exists('vc_bingo_feature')){
    function vc_bingo_feature(){
        vc_map([
            'name'  => __('Feature Section','bingo'),
            'base'  => 'feature',
            'category'  => __('Bingo Addons',' bingo '),
            'params'    => [
                [
                    'type'  => 'textfield',
                    'heading'   => __('Descripton','bingo'),
                    'param_name'    => 'description_1',
                    'description'   => __('Enter Some text to show', 'bingo')
                ],
                [
                    'type'  => 'textfield',
                    'heading'   => __('Descripton','bingo'),
                    'param_name'    => 'description_2',
                    'description'   => __('Enter Some text to show', 'bingo')
                ],
                [
                    'type'  => 'textfield',
                    'heading'   => __('Title','bingo'),
                    'param_name'    => 'title_text',
                    'description'   => __('Write Title', 'bingo')
                ],
                [
                    'type'  => 'textfield',
                    'heading'   => __('Button','bingo'),
                    'param_name'    => 'button_text',
                    'description'   => __('Button Text', 'bingo')
                ],
                [
                    'type'  => 'textfield',
                    'heading'   => __('Button LInk','bingo'),
                    'param_name'    => 'button_link',
                    'description'   => __('Button LInk', 'bingo')
                ],
                [
                    'type'  => 'param_group',
                    'heading'   => __('Feature List','bingo'),
                    'param_name'    => 'features',
                    'params'        => [
                        [
                            'type'  => 'textfield',
                            'heading'   => __('Feature Name','bingo'),
                            'param_name'    => 'feature',
                            'description'   => __('Enter Feature Name', 'bingo')
                        ]
                    ]
                ]
            ]
        ]);
    }
    add_action('vc_before_init','vc_bingo_feature');
}