<?php 

if( ! function_exists('bingo_cta_vc')){
    function bingo_cta_vc(){
        vc_map([
            'name'  => __('Call To Action','bingo'),
            'base'  => 'bingo_cta',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'textarea',
                    'heading'   => __('CTA Text','bingo'),
                    'param_name'    => 'cta_text',
                    'description'   => __('Enter Some text to show','bingo')
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_cta_vc');
}