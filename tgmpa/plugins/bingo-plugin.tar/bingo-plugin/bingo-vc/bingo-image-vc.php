<?php 

if( ! function_exists('bingo_image_vc')){
    function bingo_image_vc(){
        vc_map([
            'name'  => __('Image ', 'bingo'),
            'base'  => 'about_image',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'attach_image',
                    'heading'   => __('Add Image','bingo'),
                    'param_name'    => 'image',
                    'description'   => __('Upload an image',' bingo')
                ],
                [
                    'type'  => 'textfield',
                    'heading'   => __('Alter Text','bingo'),
                    'param_name'    => 'alt_text',
                    'description'   => __('Ex: About-Us-Image','bingo')
                ]
            ]
        ]);
    }   
    add_action('vc_before_init', 'bingo_image_vc');
}