<?php 

if ( ! function_exists('bingo_team_vc')){
    function bingo_team_vc(){
        vc_map([
            'name'  => __('Team','bingo'),
            'base'  => 'team',
            'category' => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'textfield',
                    'heading'   => __('Add Title','bingo'),
                    'param_name'    => 'title_text',
                    'description'   => __('Ex: Our Team','bingo')
                ],
                [
                    'type'  => 'textarea_html',
                    'heading'   => __('Add Content','bingo'),
                    'param_name'    => 'content_text',
                    'description'   => __('Enter some text to show','bingo')
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_team_vc');
}