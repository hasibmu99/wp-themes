<?php 

if( ! function_exists('bingo_slider_vc')){
    function bingo_slider_vc(){
        vc_map([
            'name'  => 'Slider',
            'base'  => 'bingo_slider',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'textfield',
                    'heading'   => __('Post Limit','bingo'),
                    'param_name'    => 'post_limit',
                    'value'         => '3',
                    'description'   => __('Enter how may slider do you want','bingo')
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_slider_vc');
}