<?php 

if( ! function_exists('bingo_portfolio_vc')){
    function bingo_portfolio_vc(){
        vc_map([
            'name'  => __('Portfolio','bingo'),
            'base'  => 'portfolio',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'textfield',
                    'heading'   => __('Post Linit','bingo'),
                    'param_name'    => 'post_limit',
                    'description'   => __('Ex: -1')
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_portfolio_vc');
}