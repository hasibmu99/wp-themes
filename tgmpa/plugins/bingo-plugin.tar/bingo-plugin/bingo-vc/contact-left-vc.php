<?php 

if( ! function_exists('bingo_contact_left_vc')){
    function bingo_contact_left_vc(){
         vc_map([
            'name'  => __('Contact Left','bingo'),
            'base'  => 'contact_left',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'textfield',
                    'heading'   => __('Add Title','bingo'),
                    'param_name'    => 'title_text',
                    'description'   => __('Enter the Title','bingo')
                ],
                [
                    'type'  => 'textarea',
                    'heading'   => __('Add Content','bingo'),
                    'param_name'    => 'content_text',
                    'description'   => __('Enter some text to show as description','bingo')
                ],
                [
                    'type'  => 'textfield',
                    'heading'   => __('Add Address','bingo'),
                    'param_name'    => 'address',
                    'description'   => __('Enter the Address','bingo')
                ],
                [
                    'type'  => 'textfield',
                    'heading'   => __('Add Phone Number','bingo'),
                    'param_name'    => 'phone_number',
                    'description'   => __('Enter Phone Number','bingo')
                ],
                [
                    'type'  => 'textfield',
                    'heading'   => __('Add Fax Number','bingo'),
                    'param_name'    => 'fax_number',
                    'description'   => __('Enter Fax Number','bingo')
                ],
                [
                    'type'  => 'textfield',
                    'heading'   => __('Add Email Address','bingo'),
                    'param_name'    => 'email',
                    'description'   => __('Enter Email Address','bingo')
                ]
            ]

         ]);
    }
    add_action('vc_before_init','bingo_contact_left_vc');
}