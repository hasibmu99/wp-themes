<?php

if( ! function_exists('bingo_touch_vc')){
    function bingo_touch_vc(){
        vc_map([
            'name'  => __('Get Section','bingo'),
            'base'  => 'touch',
            'category'  => __('Bingo Addons','bingo'),
            'params'    => [
                [
                    'type'  => 'textfield',
                    'heading'   => __('Add Title','bingo'),
                    'param_name'    => 'title_text',
                    'description'   => __('Enter the Title','bingo'),
                    'admin_label'   => true
                ],
                
                [
                    'type'  => 'textarea',
                    'heading'   => __('Add content','bingo'),
                    'param_name'    => 'content_text',
                    'description'   => __('Enter soem text to show as content','bingo')
                ],
            ]
        ]); 
    }
    add_action('vc_before_init','bingo_touch_vc');
}