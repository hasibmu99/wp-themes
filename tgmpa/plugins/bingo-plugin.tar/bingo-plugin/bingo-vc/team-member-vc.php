<?php
if( ! function_exists('bingo_own_member')){
    function bingo_own_member(){
        vc_map([
            'name'  => __('Team Member','bingo'),
            'base'  => 'team_khiladi',
            'category'  =>  __('Bingo Addons','bingo'),
            'params'     => [
                [
                    'type'  => 'param_group',
                    'heading'   => __('Add Member Info','bingo'),
                    'param_name'    => 'members',
                    'params'        => [
                        [
                            'type'  => 'attach_image',
                            'heading'   => __('Image of Member','bingo'),
                            'param_name'    => 'member_image',
                            'description'   => __('Upload an image of Team Member','bingo')
                        ],
                        [
                            'type'  => 'textfield',
                            'heading'   => __('Name','bingo'),
                            'param_name'    => 'member_name',
                            'description'   => __('Enter some text to show','bingo')
                        ],
                        [
                            'type'  => 'textfield',
                            'heading'   => __('Designation','bingo'),
                            'param_name'    => 'designation',
                            'description'   => __('Ex: CEO','bingo')
                        ],
                        [
                            'type'  => 'textarea_html',
                            'heading'   => __('Description','bingo'),
                            'param_name'    => 'description',
                            'description'   => __('Enter some text to show','bingo')
                        ]

                    ]
                ]
            ]
        ]);
    }
    add_action('vc_before_init','bingo_own_member');
}