<?php 

if( ! function_exists('bingo_pricing_table_vc')){
    function bingo_pricing_table_vc(){
        vc_map([
            'name'      => __('Pricing Table', 'bingo'),
            'base'      => 'plans',
            'category'  => __('Bingo Addons', 'bingo'),
            'params'    => [
                [
                    'type'          => 'textfield',
                    'heading'       => __('Pricing Title','bingo'),
                    'param_name'    => 'title_text',
                    'description'   => __('Enter the Title','bingo')
                ],
                [
                    'type'          => 'textarea',
                    'heading'       => __('Pricing Content','bingo'),
                    'param_name'    => 'content_text',
                    'description'   => __('Enter the Content Text','bingo')
                ],
                [
                    'type'          => 'param_group',
                    'heading'       => __('Add Item','bingo'),
                    'param_name'    => 'items',
                    'params'        => [
                        [
                            'type'          => 'textfield',
                            'heading'       => __('Product Type','bingo'),
                            'param_name'    => 'product_type',
                            'description'   => __('Ex: Basic','bingo')
                        ],
                        [
                            'type'          => 'textfield',
                            'heading'       => __('Product Price','bingo'),
                            'param_name'    => 'price',
                            'description'   => __('Ex: $99')
                        ],
                        [
                            'type'          => 'textarea',
                            'heading'       => __('Product Detail','bingo'),
                            'param_name'    => 'product_detail',
                            'description'   => __('Enter some text to show','bingo')
                        ],
                        [
                            'type'          => 'textfield',
                            'heading'       => __('Button ','bingo'),
                            'param_name'    => 'button_text',
                            'description'   => __('Enter button text','bingo')
                        ],
                        [
                            'type'          => 'textfield',
                            'heading'       => __('Button Link','bingo'),
                            'param_name'    => 'button_link',
                            'description'   => __('Enter button link','bingo')
                        ],
                        [
                            'type'          => 'textfield',
                            'heading'       => __('Icon Class','bingo'),
                            'param_name'    => 'icon_class',
                            'description'   => __('Enter icon class','bingo')
                        ]
                    ]
                ]
                
            ]
        ]);
    }
    add_action('vc_before_init','bingo_pricing_table_vc');
}