<?php 

/**
 * @package bingo
 * @version 1.7
 */
/*
Plugin Name:  Bingo-core
Description: This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong: Hello, Dolly. When activated you will randomly see a lyric from <cite>Hello, Dolly</cite> in the upper right of your admin screen on every page.
Author: Hasib Muhammad


*/

foreach(glob(plugin_dir_path(__FILE__) .'/shortcodes/*.php') as $file){
    require_once($file);
}

foreach(glob(plugin_dir_path(__FILE__). 'bingo-vc/*.php') as $file){
    require_once($file);
}

foreach(glob(plugin_dir_path(__FILE__). 'custom-widgets/*.php') as $file){
    require_once($file);
}

require_once (plugin_dir_path(__FILE__) . 'demo-importer/bingo-demo-importer.php');