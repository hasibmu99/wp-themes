<?php 

if( ! function_exists('team_member_details')){
    function team_member_details($atts){
        extract(shortcode_atts([
            'members'   => ''
        ],$atts));

        $members = vc_param_group_parse_atts($members);

        $html = '';

        ob_start();

        ?>
            <?php foreach($members as $member): $image = wp_get_attachment_image_src($member['member_image'],'full'); ?>
            
            <span class ="team">
                <div class="col-md-4 col-sm-6 ">
                    <div class="team-member text-center">
                        <div class="member-photo">
                            
                            <img class="img-responsive" src="<?php echo esc_url($image[0]);?>">
                            

                            
                            <div class="mask">
                                <ul class="clearfix">
                                    <li>
                                        <a href="#">
                                            <i class="tf-ion-social-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="tf-ion-social-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="tf-ion-social-google-outline"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="tf-ion-social-dribbble"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            
                        </div>

                        
                        <div class="member-content">
                            <h3><?php echo esc_attr($member['member_name']); ?></h3>
                            <span><?php echo esc_attr($member['designation']); ?></span>
                            <p><?php echo wp_kses_post($member['description']); ?></p>
                        </div>
                        

                    </div>
                </div>
    
            </span>
            <?php endforeach; ?>

        <?php 
        $html .= ob_get_clean();
        return $html;
    }
    add_shortcode('team_khiladi','team_member_details');
}