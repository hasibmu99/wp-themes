<?php

if( ! function_exists('bingo_contact_left')){
    function bingo_contact_left($atts){
        extract(shortcode_atts([
            'title_text'    => '',
            'content_text'  => '',
            'address'       => '',
            'phone_number'  => '',
            'fax_number'    => '',
            'email'         => ''
        ],$atts));

        ob_start();

        ?>
        <div class="contact-details" >
            <h3><?php echo esc_attr($title_text); ?></h3>
            <?php echo wp_kses_post(wpautop($content_text)); ?>
            <ul class="contact-short-info" >
                <li>
                    <i class="tf-ion-ios-home"></i>
                    <span><?php echo esc_attr($address); ?></span>
                </li>
                <li>
                    <i class="tf-ion-android-phone-portrait"></i>
                    <span>Phone: <?php echo esc_attr($phone_number); ?></span>
                </li>
                <li>
                    <i class="tf-ion-android-globe"></i>
                    <span>Fax: <?php echo esc_attr($fax_number); ?></span>
                </li>
                <li>
                    <i class="tf-ion-android-mail"></i>
                    <span>Email: <?php echo esc_attr($email); ?></span>
                </li>
            </ul>

            <div class="social-icon">
                <ul>
                    <li><a href="#"><i class="tf-ion-social-facebook"></i></a></li>
                    <li><a href="#"><i class="tf-ion-social-twitter"></i></a></li>
                    <li><a href="#"><i class="tf-ion-social-dribbble-outline"></i></a></li>
                    <li><a href="#"><i class="tf-ion-social-linkedin-outline"></i></a></li>
                </ul>
            </div>
		</div>

        <?php

        return ob_get_clean();
    }
    add_shortcode('contact_left','bingo_contact_left');
}