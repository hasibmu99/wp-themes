<?php 

if( ! function_exists('bingo_feature_list')){
    function bingo_feature_list($atts){
        extract(shortcode_atts([
            'description_1' => '',
            'description_2' => '',
            'title_text'    => '',
            'features'      => '',
            'button_text'   => '',
            'button_link'   => ''
        ],$atts));
        ob_start();

         
        $features = vc_param_group_parse_atts($features);

        ?>
        <section class="about" id="about">
                    
            <?php echo wp_kses_post(wpautop($description_1)); ?>

            <?php echo wp_kses_post(wpautop($description_2)); ?>

            <h4><?php echo esc_attr($title_text); ?></h4>


            <ul class="feature-list">
                <?php foreach( $features as $feature ) : ?>
                    <li> <i class="tf-ion-android-checkmark-circle"></i><?php echo esc_attr($feature['feature']); ?></li>
                <?php endforeach;?>
            </ul>
            
            <a href="<?php echo esc_url($button_link); ?>" class="btn btn-main mt-20"><?php echo esc_attr($button_text); ?></a>
                       	
        </section>

        <?php 

        return ob_get_clean();
    }
    add_shortcode('feature', 'bingo_feature_list');
}