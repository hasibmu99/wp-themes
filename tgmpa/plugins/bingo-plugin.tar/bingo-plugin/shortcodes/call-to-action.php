<?php 

if ( ! function_exists('bingo_call_to_action')){
    function bingo_call_to_action($atts){ 

        extract(shortcode_atts([
            'cta_text'  => '',
        ], $atts) );

        $html = '';
        ob_start();

        

        ?>
        <section class="call-to-action-2 section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h2><?php echo esc_attr($cta_text) ?></h2>
                    </div>
                </div> 		<!-- End row -->
            </div>   	<!-- End container -->
        </section>
        
        <?php
        
        $html .= ob_get_clean();
        return $html;

    }
    add_shortcode('bingo_cta','bingo_call_to_action');
}