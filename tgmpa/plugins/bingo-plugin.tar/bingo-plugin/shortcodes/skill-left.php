<?php 

if(! function_exists('bingo_skill_left')){
    function bingo_skill_left($atts){
        extract(shortcode_atts([
            'title_text'    => '',
            'content_text'  => '',
            'button_text'   => '',
            'button_link'   => ''
        ],$atts));

        ob_start();

        ?>
        
        <section class="team-skills-content">

            <h2><?php echo $title_text; ?></h2>
            <?php echo wp_kses_post(wpautop($content_text)) ;?>
            <a href="<?php echo esc_url($button_link); ?>" class="btn btn-main mt-20"><?php echo esc_attr($button_text); ?></a>

        </section> 

        <?php

        return ob_get_clean();

    }
    add_shortcode('skill_left','bingo_skill_left');
}