<?php

if( ! function_exists('bingo_latest_post')){
    function bingo_latest_post($atts){
        extract(shortcode_atts([
            'title_text'    => '',
            'content_text'  => '',
            'post_limit'    => ''
        ],$atts));


        $query = new WP_Query([
            'post_type' => 'post',
            'posts_per_page'    => $post_limit,
            'orderby'           => 'menu_order',
            'order'             => 'ASC'
        ]);

        ob_start();
        ?>
        <section class="blog" id="blog">
		    <div class="container">
			    <div class="row">
                    <div class="title text-center ">
                        <h2><?php echo esc_attr($title_text); ?></h2>
                        <div class="border"></div>
                        <p><?php echo wp_kses_post($content_text); ?></p>
                    </div>
                <?php 
                    while($query->have_posts()) : $query->the_post();
                        $image_id = get_post_thumbnail_id(get_the_ID());

                        $image = wp_get_attachment_image_src($image_id,'full');

                        $button_options = get_post_meta(get_the_ID(),'_custom_metabox',true);
                    

                        
                ?>
                    <article class="col-md-4 col-sm-6 col-xs-12 clearfix " >
                        <div class="post-item">
                            <div class="media-wrapper">
                                <img src="<?php echo esc_attr($image[0]); ?>" alt="amazing caves coverimage" class="img-responsive">
                            </div>
                            
                            <div class="content">
                                <h3><a href="single-post.html"><?php echo esc_attr(the_title()); ?></a></h3>
                                <?php esc_attr(the_content()); ?>
                                <a class="btn btn-main" href="<?php echo esc_url($button_options['button_link']); ?>"><?php echo esc_attr($button_options['button_text']);  ?></a>
                            </div>
                        </div>						
                    </article>
                <?php endwhile;?>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
    add_shortcode('latest_post','bingo_latest_post');
}


if( ! function_exists('bingo_custom_meta')){
    function bingo_custom_meta($options){
        $options = [];

        $options[] = [
            'id'    => '_custom_metabox',
            'title' => __('Custom Options','bingo'),
            'post_type' => 'post',
            'context'  =>  'normal',
            'priority'  => 'default',
            'sections'  => [
                [
                    'name'  => __('Text','bingo'),
                    'title' => __('Button Text','bingo'),
                    'icon'  => 'fa fa-wifi',
                    'fields'    => [
                        [
                            'id'   => 'button_text',
                            'type'  => 'text',
                            'title' => __('Button Text','bingo')
                        ]
                        
                    ]
                    

                ],

                [
                    'name'  => __('Links','bingo'),
                    'title' => __('Button Links','bingo'),
                    'icon'  => 'fa fa-wifi',
                    'fields'    => [
                        [
                            'id'    => 'button_link',
                            'type'  => 'text',
                            'title' => __('Button Link','bingo')
                        ]
                    ]
                ]
            ]
        ];
        return apply_filters('my_custom_metabox',$options);
    }
    add_action('cs_metabox_options','bingo_custom_meta');
}