<?php 

if( ! function_exists('our_services_shortcode')){

    function our_services_shortcode($atts){
        extract(shortcode_atts([
            'services'  => ''
        ],$atts));

        ob_start();

        $services = vc_param_group_parse_atts($services);
        
        


        ?>
        <section class="services" id = "services">
            <div class="contaner">
                <div class="row">
                    <?php foreach($services as $service): ?>

                     <div class="col-md-4 col-sm-6 col-xs-12  no-padding" >
                        <div class="service-block color-bg  text-center">
                            <div class="service-icon text-center">
                                <i class="tf-ion-ios-copy-outline"></i>
                            </div>
                            <h3><?php echo esc_attr($service['title_text']); ?></h3>
                            <?php echo wp_kses_post(wpautop($service['content_text'])); ?>
                        </div>
                    </div>
                    
                    <?php endforeach; ?>
                    
                </div>
            </div>
        </section>

        <?php
    }
    add_shortcode('bingo_services','our_services_shortcode');

}