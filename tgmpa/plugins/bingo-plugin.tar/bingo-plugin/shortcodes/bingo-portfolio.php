<?php


if ( ! function_exists('bingo_portfolio')){
    function bingo_portfolio($atts){
        extract(shortcode_atts([
            'post_limit'    => ''
        ],$atts));

        ob_start();
        ?>
            <section class="" id="portfolio">
			<div class="container-fluid">
				<div class="row " >
					<div class="col-lg-12">

                    <?php
                         $terms = get_terms([
                            'taxonomy'      => 'portfolios_category',
                            'hide_empty'    => false
                            
                        ]);

                        
                    ?>
                    <div class="portfolio-filter">
                        <button type="button" data-filter="all"><?php echo _e('All'); ?></button>
                        <?php foreach($terms as $term): ?>
                            <button type="button" data-filter=".<?php echo esc_attr($term->slug) ?>"><?php echo esc_attr($term->name); ?></button>
                        <?php endforeach; ?>
                    </div>

						

                    <?php 
                    
                    $query = new WP_Query([
                        'post_type'         => 'bingo_portfolio',
                        'posts_per_page'    => $post_limit,
                        'orderby'           => 'menu_order',
                        'order'             => 'ASC'
                    ]);

                    
                    ?>
                    <?php 
                        if($query->have_posts()):
                    ?>
						<div class="portfolio-items-wrapper">
							<div class="row">
                            <?php 
                                while($query->have_posts()): $query->the_post(); 
                                    $image_id = get_post_thumbnail_id(get_the_ID());
                                    $image = wp_get_attachment_image_src($image_id,'full');

                                    $classes = wp_get_post_terms(get_the_ID(),'portfolios_category', true);

                                    $temp_class = [];
                                    foreach($classes as $class){
                                        $temp_class[] =  $class->slug;
                                    }
                                    $final_class = implode($temp_class, ' ');
                            ?>
								<div class="col-md-3 col-sm-6 col-xs-6 mix <?php echo $final_class; ?>" >
							    	<div class="portfolio-block">
							    		<img class="img-responsive" src="<?php echo $image[0]; ?>" alt="">
							    		<div class="caption">
							    			<a class="search-icon" href="<?php echo $image[0]; ?>" data-lightbox="image-1">
							    				<i class="tf-ion-ios-search-strong"></i>
								    		</a>
							    			<h4><a href=""><?php echo esc_attr(the_title()); ?></a></h4>
							    		</div>
                                    
							    	</div>
							    </div>
                            <?php endwhile; ?>
							    
							</div>
						</div>
                    <?php endif;?>
						
					</div> <!-- /end col-lg-12 -->
				</div> <!-- end row -->
			</div>	<!-- end container -->
		</section>   <!-- End section -->

        <?php 
        return ob_get_clean();
    }

    add_shortcode('portfolio','bingo_portfolio');
}