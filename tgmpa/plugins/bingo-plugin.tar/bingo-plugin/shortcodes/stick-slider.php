<?php 

if( ! function_exists('bingo_stick_slider')){
    function bingo_stick_slider($atts){
        extract(shortcode_atts([
            'stick_images'   => ''
        ],$atts));

        $html = '';
        $images = vc_param_group_parse_atts($stick_images);
        ob_start();

        $html .= '<div id="clients-slider" class="clients-logo-slider">';
        

        ?>
        <?php 
            foreach($images as $image): 
                $image = wp_get_attachment_image_src($image['image'],'full') 
        ?>
            <img src="<?php echo esc_attr($image[0]); ?> " alt="">
        <?php endforeach; ?>
        <?php
        
        $html .= ob_get_clean();
        $html .= '</div>';
        return $html;
    }
    add_shortcode('stick_slider','bingo_stick_slider');
}