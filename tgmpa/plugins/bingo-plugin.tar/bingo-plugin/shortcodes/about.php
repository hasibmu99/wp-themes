<?php 
            
if( ! function_exists('bingo_about')){
    function bingo_about($atts){
        extract(shortcode_atts([
            'title_text'    => '',
            'content_text'  => ''
        ],$atts));

        ob_start();
        ?>
        <section class="about">
            <div class="title text-center"  >
				<h2><?php echo esc_attr($title_text); ?></h2>
				<?php echo wp_kses_post(wpautop($content_text)); ?>
				<div class="border"></div>
            </div>
        </section>

        <?php 

        return ob_get_clean();
    }   
    add_shortcode('about','bingo_about');
}