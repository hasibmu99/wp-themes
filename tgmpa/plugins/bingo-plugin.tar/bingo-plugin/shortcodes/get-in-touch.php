<?php

if( ! function_exists('bingo_get_in_touch')){
    function bingo_get_in_touch($atts){
        extract(shortcode_atts([
            'title_text'    => '',
            'content_text'  => ''
        ],$atts));

        ob_start();

        ?>
        <div class="title text-center" >
            <h2><?php echo esc_attr($title_text) ;?></h2>
            <p><?php echo wp_kses_post($content_text); ?></p>
            <div class="border"></div>
        </div>
        <?php
        return ob_get_clean();
    }
    add_shortcode('touch','bingo_get_in_touch');
}