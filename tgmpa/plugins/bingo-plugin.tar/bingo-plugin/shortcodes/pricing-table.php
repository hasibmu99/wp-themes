<?php 


if( ! function_exists('our_pricing_table_shortcode')){
    function our_pricing_table_shortcode($atts){
        extract(shortcode_atts([
            'title_text'     => '',
            'content_text'   => '',
            'items'      => ''

        ],$atts));

        $products = vc_param_group_parse_atts($items);

        ob_start();
        ?>
            <section class="pricing-table " id="pricing">
                    <div class="container">
                        <div class="row">
                            
                            <!-- section title -->
                            <div class="title title-white text-center " >
                                <h2><?php echo esc_attr($title_text); ?></h2>
                                <p><?php echo esc_attr($content_text); ?></p>
                                <div class="border"></div>
                            </div>
                            <!-- /section title -->
                            
                            <?php foreach($products as $product): ?>
                            <div class="col-md-4 col-sm-6 col-xs-12" >
                                <div class="pricing-item">
                                    
                                    <!-- plan name & value -->
                                    <div class="price-title">
                                        <h3><?php echo esc_attr($product['product_type']); ?></h3>
                                        <strong class="value">$<?php echo esc_attr($product['price']) ?></strong>
                                        <p><?php echo wp_kses_post($product['product_detail']); ?></p>
                                    </div>
                                    <!-- /plan name & value -->
                                    
                                    <!-- plan description -->
                                    <ul>
                                        <li><i class="tf-ion-ios-<?php echo esc_attr($product['icon_class']) ?>"></i> 1GB Disk Space</li>
                                        <li><i class="tf-ion-ios-<?php echo esc_attr($product['icon_class']) ?>"></i> 10 Email Account</li>
                                        <li><i class="tf-ion-ios-<?php echo esc_attr($product['icon_class']) ?>"></i> Script Installer</li>
                                        <li><i class="tf-ion-ios-<?php echo esc_attr($product['icon_class']) ?>"></i> 1 GB Storage</li>
                                        <li><i class="tf-ion-ios-<?php echo esc_attr($product['icon_class']) ?>"></i> 10 GB Bandwidth</li>
                                        <li><i class="tf-ion-ios-<?php echo esc_attr($product['icon_class']) ?>"></i> 24/7 Tech Support</li>
                                    </ul>
                                    <!-- /plan description -->
                                    
                                    <!-- signup button -->
                                    <a class="btn btn-main" href="<?php echo esc_attr($product['button_link']); ?>"><?php echo esc_attr($product['button_text']); ?></a>
                                    <!-- /signup button -->
                                    
                                </div>
                            </div>
                            <?php endforeach; ?>
                    
                        </div>
                    </div>   
                </section>  
        <?php 
        return ob_get_clean();
    }
    add_shortcode('plans','our_pricing_table_shortcode');
}