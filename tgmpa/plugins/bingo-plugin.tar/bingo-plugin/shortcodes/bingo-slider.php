<?php

if( ! defined('ABSPATH')) {die;}

if( ! function_exists('bingo_slider_shortcode')){
	function bingo_slider_shortcode($atts){
		extract(shortcode_atts([
			'post_limit'	=> ''
		],$atts));

		$query = new WP_Query([
			'post_type'			=> 'bingo_slider',
			'posts_per_page'	=> $post_limit,
			'orderby'			=> 'menu_order',
			'order'				=> 'ASC'
		]);

		

		ob_start();
		?>
		<?php 
			while($query->have_posts()): $query->the_post(); 

				$slide_options = get_post_meta(get_the_ID(), 'custom_meta_slider', true);
				

				$image_id = get_post_thumbnail_id(get_the_ID());
				$image = wp_get_attachment_image_src($image_id, 'full');
		?>
			<section class="hero-area" style = "background-image: url(<?php echo esc_attr($image[0]); ?>);">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="block" >
								<h1 class="wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".3s" ><?php the_title(); ?></h1>
								<p class="wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".5s"><?php the_content(); ?></p>
								<ul class="list-inline wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".7s">
								
									<?php if( ! empty($slide_options['link_1'] || $slide_options['text_1']) ) : ?>
										<li>
											<a data-scroll href="<?php echo esc_url($slide_options['link_1']); ?>" class="btn btn-main"><?php echo esc_attr($slide_options['text_1']); ?></a>		
										</li>
									<?php endif;?>

									<?php if( ! empty($slide_options['link_2'] || $slide_options['text_2']) ) : ?>
										<li>
											<a data-scroll href="<?php echo esc_url($slide_options['link_2']); ?>" class="btn btn-transparent"><?php echo esc_attr($slide_options['text_2']); ?></a>		
										</li>
									<?php endif; ?>
									

								</ul>
							</div>
						</div>
					</div>
				</div>
			</section>

		<?php endwhile; ?>

		<?php 

		return ob_get_clean();
	}

	add_shortcode('bingo_slider','bingo_slider_shortcode');
}

if( ! function_exists('bingo_metabox')){
	function bingo_metabox($options){

		$options = [];

		$options[] = [
			 'id'            => 'custom_meta_slider',
			'title'         => 'Slider Options',
			'post_type'     => 'bingo_slider', 
			'context'       => 'normal',
			'priority'      => 'default',
			'sections'		=> [
				[
					'name'      => 'Button1',
					'title'     => 'Button 1',
					'icon'      => 'fa fa-wifi',
					'fields'	=> [
						[
							'id'	=> 'link_1',
							'title'	=> __('Button Link 1','bingo'),
							'type'	=> 'text'
						],
						[
							'id'	=> 'text_1',
							'type'	=> 'text',
							'title'	=> __('Button Text 1','bingo')
						],

					]
				],

				[
					'name'		=> 'Button2',
					'title'		=> __('Button 2','bingo'),
					'icon'		=> 'fa fa-wifi',
					'fields'	=> [
						[
							'id'	=> 'link_2',
							'title'	=> __('Button Link 2','bingo'),
							'type'	=> 'text'
						],
						[
							'id'	=> 'text_2',
							'title'	=> __('Button Text 2', 'bingo'),
							'type'	=> 'text'
						]
					]
				]
			]
		];

		return apply_filters('cusom_slide_metabxo',$options);

	}
	add_filter('cs_metabox_options' ,'bingo_metabox');
}