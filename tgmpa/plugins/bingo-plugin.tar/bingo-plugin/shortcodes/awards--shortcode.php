<?php

if ( ! function_exists('bingo_awards_shortcode')){
    function bingo_awards_shortcode($atts){
        extract(shortcode_atts([
            'awards'    => ''
        ],$atts));
        
        $html = '';

        $total_awards = vc_param_group_parse_atts($awards);
        
        ob_start();

        ?>
        
        <?php foreach($total_awards as $award) : ?>
        <div class="col-md-3 col-sm-6 col-xs-6 text-center">
            <div class="counters-item">
                <i class="tf-ion-<?php echo esc_attr($award['icon']); ?>"></i>
                    <div>
                        <span class="counter" data-count="<?php echo esc_attr($award['max_number']); ?>"><?php echo esc_attr($award['least_number']) ?></span>
                    </div>
                <h3><?php echo esc_attr($award['title']); ?></h3>
            </div>
        </div>
        
        <?php endforeach; ?>

        <?php 
        $html .= ob_get_clean();

        return $html;


    }
    add_shortcode('bingo_awards','bingo_awards_shortcode');
}