<?php 

if( ! function_exists('bingo_testimonial_slide')){
    function bingo_testimonial_slide($atts){
        extract(shortcode_atts([
            'testimonials'  => ''
        ],$atts));

        $testimonials = vc_param_group_parse_atts($testimonials);
        

        ob_start();

        ?>
        
        <section class="testimonial section" id="testimonial">
            
            <div class="container">
                <div class="row">
                
                    <div class="col-lg-12">
                        
                        <div class="testimonial-slider">

                           <?php foreach($testimonials as $testimonial): $image = wp_get_attachment_image_src($testimonial['client_image'],'full'); ?> 

                            <div class="item text-center">
                                <i class="tf-ion-chatbubbles"></i>
                                
                                <div class="client-details">
                                    <?php echo wp_kses_post( wpautop( $testimonial['client_detail'] ) ); ?>
                                </div>
                    
                                <div class="client-thumb">
                                    <img src="<?php echo esc_url($image[0]);?>">
                                </div>
                                <div class="client-meta">
                                    <h3><?php echo esc_attr($testimonial['client_name']); ?></h3>
                                    <span><?php echo esc_attr($testimonial['client_designation']); ?></span>
                                </div>
                            </div>

                            <?php endforeach; ?>

                        </div>
                    </div>
                

                
                </div>
            </div>
    
        </section>
        


        <?php 

        return ob_get_clean();
    }
    add_shortcode('testimonial','bingo_testimonial_slide');
}