<?php
if( ! function_exists('bingo_progress')){
    function bingo_progress($atts){
        extract(shortcode_atts([
            'progresses'        => ''
        ],$atts));

        $progresses = vc_param_group_parse_atts($progresses);

        $html = '';
        ob_start();
        
        ?> 

        <?php foreach($progresses as $progress): ?>
        <div class="team-skills"><div class="progress-block">
            <ul>
                <li>
                    <span><?php echo esc_attr($progress['progress_topic']) ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width:<?php echo esc_attr($progress['percentage']); ?>%;">
                        </div>
                    </div>
                </li>
            </ul>
        </div></div>
        <?php endforeach; ?>
        

        <?php
        $html .= ob_get_clean();
        return $html;
    }
    add_shortcode('progress','bingo_progress');
}