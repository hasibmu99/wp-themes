<?php 

if( ! function_exists('bingo_about_image')){
    function bingo_about_image( $atts ){
        
        extract(shortcode_atts([
            'image' => '',
            'alt_text'  => ''
        ], $atts) );

        $images = wp_get_attachment_image_src($image, 'full');       

        ob_start();
        ?>
            <img src="<?php echo esc_url($images[0]); ?>" class="img-responsive" alt="<?php echo esc_attr($alt_text); ?>">
        <?php

        return ob_get_clean();

    }
    add_shortcode('about_image','bingo_about_image');
}