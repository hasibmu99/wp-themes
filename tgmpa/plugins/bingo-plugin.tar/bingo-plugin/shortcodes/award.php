<?php 
            
if( ! function_exists('bingo_award')){
    function bingo_award($atts){
        extract(shortcode_atts([
            'title_text'    => '',
            'content_text'  => ''
        ],$atts));

        $html = '';
        
        ob_start();
        $html .= '<div class="section-sm">';
        
        ?>
        
            <div class="title text-center"  >
				<h2><?php echo esc_attr($title_text); ?></h2>
				<?php echo wp_kses_post(wpautop($content_text)); ?>
            </div>
        
        <?php 
        $html .= '</div>';
        $html .=  ob_get_clean();
        return $html ;
        
    }   
    add_shortcode('award','bingo_award');
}