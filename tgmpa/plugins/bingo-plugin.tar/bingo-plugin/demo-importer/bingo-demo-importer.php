<?php 

if( ! function_exists('bingo_one_click_demo_importer')){
    function bingo_one_click_demo_importer(){
        return [
            [
                'import_file_name'              => __('Bingo Corporate','bingo'),
                'categories'                    => ['category 1'],
                'import_file_url'               => plugin_dir_url(__FILE__) . 'bingo-content.xml',
                'import_widget_file_url'        => plugin_dir_url(__FILE__). 'bingo-widget.wie',
                'import_customizer_file_url'    => plugin_dir_url(__FILE__) . 'bingo-customizer.dat',
                'import_preview_image_url'      => 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=e5a31d03ddee66863a599421f792e07b&auto=format&fit=crop&w=750&q=80',
                'import_notice'                 => __('
                                                            <ol>
                                                                <li>memory_limit should be 256M</li>
                                                                <li>upload_max_size should be 65M</li>
                                                                <li>upload_max_filesize should be 64M</li>
                                                                <li>max_execution_time should be 300</li>
                                                                <li>max_input_time should be 300</li>
                                                            </ol
                                                    ','bingo'),
                'preview_url'                   => 'http://preview.themeforest.net/item/bingo-one-page-parallax/full_screen_preview/20581308'
                
            ],
            [
                'import_file_name'              => __('Bingo Agency','bingo'),
                'categories'                    => ['category 2'],
                'import_file_url'               => plugin_dir_url(__FILE__) . 'bingo-content.xml',
                'import_widget_file_url'        => plugin_dir_url(__FILE__). 'bingo-widget.wie',
                'import_customizer_file_url'    => plugin_dir_url(__FILE__) . 'bingo-customizer.dat',
                'import_preview_image_url'      => 'https://images.unsplash.com/photo-1497215842964-222b430dc094?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=48fe9f87e4a3344a46e80ddf5c3bdfa6&auto=format&fit=crop&w=750&q=80',
                'import_notice'                 =>  __('
                                                            <ol>
                                                                <li>memory_limit should be 256M</li>
                                                                <li>upload_max_size should be 65M</li>
                                                                <li>upload_max_filesize should be 64M</li>
                                                                <li>max_execution_time should be 300</li>
                                                                <li>max_input_time should be 300</li>
                                                            </ol
                                                    ','bingo'),
                'preview_url'                   => 'http://preview.themeforest.net/item/bingo-one-page-parallax/full_screen_preview/20581308'
                
            ]

        ];  
    }
    add_filter('pt-ocdi/import_files','bingo_one_click_demo_importer');
    add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );
}

if( ! function_exists( 'bingo_intro_text' ) ){
    function bingo_intro_text( $intro_text ){
        $intro_text = '';

        $intro_text .= '<ol>'; 
            $intro_text .= '<li>memory_limit should be 256M</li>';
            $intro_text .= '<li>upload_max_size should be 65M</li>';
            $intro_text .= '<li>upload_max_filesize should be 64M</li>';
            $intro_text .= '<li>max_execution_time should be 300</li>';
            $intro_text .= '<li>max_input_time should be 300</li>';
        $intro_text .= '</ol>'; 

        return $intro_text;
    }
    add_filter( 'pt-ocdi/plugin_intro_text', 'bingo_intro_text' );

}


if( ! function_exists('bngo_one_click_demo_title')){
    function bingo_one_click_demo_title(){
        ob_start();

        ?>
            <h1 class="ocdi__title  dashicons-before dashicons-hammer"><?php esc_html_e( 'It is my plugin, go away from here.', 'pt-ocdi' ); ?></h1>
        <?php 
    
        return ob_get_clean();
    }
    add_filter('pt-ocdi/plugin_page_title','bingo_one_click_demo_title');
}






